"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const handler = async function (event) {
    for (let i = 0; i < event.Records.length; ++i) {
        const { body } = event.Records[i];
        console.log(body);
    }
    return null;
};
exports.handler = handler;
//# sourceMappingURL=QueueProcessor.js.map