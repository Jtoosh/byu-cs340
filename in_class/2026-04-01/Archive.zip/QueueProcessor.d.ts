export declare const handler: (event: any) => Promise<null>;
//# sourceMappingURL=QueueProcessor.d.ts.map