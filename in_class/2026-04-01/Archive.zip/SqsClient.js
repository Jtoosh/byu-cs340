"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const client_sqs_1 = require("@aws-sdk/client-sqs");
let sqsClient = new client_sqs_1.SQSClient();
async function sendMessage() {
    const sqs_url = "https://sqs.us-west-2.amazonaws.com/615299777283/class_demo_queue";
    const messageBody = "Bro ipsum dolor sit amet whistler gaper wack euro brain bucket greasy berm afterbang single track endo heli crank afterbang free ride huckfest.";
    const params = {
        DelaySeconds: 10,
        MessageBody: messageBody,
        QueueUrl: sqs_url,
    };
    try {
        const data = await sqsClient.send(new client_sqs_1.SendMessageCommand(params));
        console.log("Success, message sent. MessageID:", data.MessageId);
    }
    catch (err) {
        throw err;
    }
}
sendMessage();
//# sourceMappingURL=SqsClient.js.map