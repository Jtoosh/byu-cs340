export {};
//# sourceMappingURL=SqsClient.d.ts.map